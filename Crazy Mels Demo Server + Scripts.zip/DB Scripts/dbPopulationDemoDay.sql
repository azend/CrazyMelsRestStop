INSERT INTO _Customer VALUES ('Joe','Bzolay','555-555-1212');
INSERT INTO _Customer VALUES ('Nancy','Finklbaum','555-235-4578');
INSERT INTO _Customer VALUES ('Henry','Svitzinski','555-326-8456');

INSERT INTO _Product VALUES ('Grapple Grommet','0.005','0.02','1');
INSERT INTO _Product VALUES ('Wandoozals','0.532','2.35','1');
INSERT INTO _Product VALUES ('Kardoofals','8.75','5.65','0');

INSERT INTO _Order VALUES ('1','GRAP-09-2011-001','09/15/2011');
INSERT INTO _Order VALUES ('1','GRAP-09-2011-056','09/30/2011');
INSERT INTO _Order VALUES ('3','','10/05/2011');

INSERT INTO _Cart VALUES ('1','1','500');
INSERT INTO _Cart VALUES ('1','2','1000');
INSERT INTO _Cart VALUES ('2','3','10');
INSERT INTO _Cart VALUES ('3','1','75');
INSERT INTO _Cart VALUES ('3','2','15');
INSERT INTO _Cart VALUES ('3','3','5');