﻿namespace CrazyMelsClient
{
    partial class Screen3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Screen3));
            this.titleLabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.total_label = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.subtotal_label = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.tax_label = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.column5_listbox = new System.Windows.Forms.ListBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.column5_label = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.column4_listbox = new System.Windows.Forms.ListBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.column4_label = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.column3_listbox = new System.Windows.Forms.ListBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.column3_label = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.column2_listbox = new System.Windows.Forms.ListBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.column2_label = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.column1_listbox = new System.Windows.Forms.ListBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.column1_label = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.totalOrderWeight_label = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.totalNumOrderPieces_label = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.poNumber_label = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.orderDate_label = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.phoneNumber_label = new System.Windows.Forms.Label();
            this.firstLastName_label = new System.Windows.Forms.Label();
            this.custID_label = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.print_button = new System.Windows.Forms.Button();
            this.exit_button = new System.Windows.Forms.Button();
            this.back_button = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.BackColor = System.Drawing.SystemColors.Control;
            this.titleLabel.Font = new System.Drawing.Font("Playbill", 46F);
            this.titleLabel.ForeColor = System.Drawing.Color.Red;
            this.titleLabel.Location = new System.Drawing.Point(311, 10);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(600, 62);
            this.titleLabel.TabIndex = 5;
            this.titleLabel.Text = "CRAZY MEL\'S SHOPPING EMPORIUM";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.panel13);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.totalOrderWeight_label);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.totalNumOrderPieces_label);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.poNumber_label);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.orderDate_label);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.phoneNumber_label);
            this.panel1.Controls.Add(this.firstLastName_label);
            this.panel1.Controls.Add(this.custID_label);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(322, 76);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(589, 526);
            this.panel1.TabIndex = 52;
            // 
            // panel13
            // 
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel13.Controls.Add(this.total_label);
            this.panel13.Controls.Add(this.label24);
            this.panel13.Controls.Add(this.panel14);
            this.panel13.Controls.Add(this.panel15);
            this.panel13.Location = new System.Drawing.Point(354, 343);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(209, 103);
            this.panel13.TabIndex = 18;
            // 
            // total_label
            // 
            this.total_label.AutoSize = true;
            this.total_label.Location = new System.Drawing.Point(72, 77);
            this.total_label.Name = "total_label";
            this.total_label.Size = new System.Drawing.Size(39, 13);
            this.total_label.TabIndex = 3;
            this.total_label.Text = "<total>";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(28, 77);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(37, 13);
            this.label24.TabIndex = 2;
            this.label24.Text = "Total :";
            // 
            // panel14
            // 
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel14.Controls.Add(this.subtotal_label);
            this.panel14.Controls.Add(this.label22);
            this.panel14.Location = new System.Drawing.Point(0, 0);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(209, 38);
            this.panel14.TabIndex = 0;
            // 
            // subtotal_label
            // 
            this.subtotal_label.AutoSize = true;
            this.subtotal_label.Location = new System.Drawing.Point(70, 4);
            this.subtotal_label.Name = "subtotal_label";
            this.subtotal_label.Size = new System.Drawing.Size(56, 13);
            this.subtotal_label.TabIndex = 1;
            this.subtotal_label.Text = "<subtotal>";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(11, 6);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(52, 13);
            this.label22.TabIndex = 0;
            this.label22.Text = "Subtotal :";
            // 
            // panel15
            // 
            this.panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel15.Controls.Add(this.tax_label);
            this.panel15.Controls.Add(this.label23);
            this.panel15.Location = new System.Drawing.Point(0, 36);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(209, 38);
            this.panel15.TabIndex = 1;
            // 
            // tax_label
            // 
            this.tax_label.AutoSize = true;
            this.tax_label.Location = new System.Drawing.Point(68, 5);
            this.tax_label.Name = "tax_label";
            this.tax_label.Size = new System.Drawing.Size(33, 13);
            this.tax_label.TabIndex = 1;
            this.tax_label.Text = "<tax>";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(3, 5);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(60, 13);
            this.label23.TabIndex = 0;
            this.label23.Text = "Tax (13%) :";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.column5_listbox);
            this.panel2.Controls.Add(this.panel12);
            this.panel2.Controls.Add(this.panel10);
            this.panel2.Controls.Add(this.panel8);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(24, 81);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(539, 262);
            this.panel2.TabIndex = 17;
            // 
            // column5_listbox
            // 
            this.column5_listbox.BackColor = System.Drawing.SystemColors.Control;
            this.column5_listbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.column5_listbox.FormattingEnabled = true;
            this.column5_listbox.Items.AddRange(new object[] {
            "<unitWeight1>",
            "<unitWeight2>",
            "<unitWeight3>"});
            this.column5_listbox.Location = new System.Drawing.Point(439, 38);
            this.column5_listbox.Name = "column5_listbox";
            this.column5_listbox.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.column5_listbox.Size = new System.Drawing.Size(99, 223);
            this.column5_listbox.TabIndex = 57;
            // 
            // panel12
            // 
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel12.Controls.Add(this.column5_label);
            this.panel12.Location = new System.Drawing.Point(439, 0);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(100, 37);
            this.panel12.TabIndex = 23;
            // 
            // column5_label
            // 
            this.column5_label.AutoSize = true;
            this.column5_label.Location = new System.Drawing.Point(23, 10);
            this.column5_label.Name = "column5_label";
            this.column5_label.Size = new System.Drawing.Size(63, 13);
            this.column5_label.TabIndex = 0;
            this.column5_label.Text = "Unit Weight";
            // 
            // panel10
            // 
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.column4_listbox);
            this.panel10.Controls.Add(this.panel11);
            this.panel10.Location = new System.Drawing.Point(330, 0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(109, 262);
            this.panel10.TabIndex = 22;
            // 
            // column4_listbox
            // 
            this.column4_listbox.BackColor = System.Drawing.SystemColors.Control;
            this.column4_listbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.column4_listbox.FormattingEnabled = true;
            this.column4_listbox.Items.AddRange(new object[] {
            "<quantity1>",
            "<quantity2>",
            "<quantity3>"});
            this.column4_listbox.Location = new System.Drawing.Point(0, 37);
            this.column4_listbox.Name = "column4_listbox";
            this.column4_listbox.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.column4_listbox.Size = new System.Drawing.Size(108, 223);
            this.column4_listbox.TabIndex = 56;
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.column4_label);
            this.panel11.Location = new System.Drawing.Point(0, 0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(109, 37);
            this.panel11.TabIndex = 0;
            // 
            // column4_label
            // 
            this.column4_label.AutoSize = true;
            this.column4_label.Location = new System.Drawing.Point(28, 10);
            this.column4_label.Name = "column4_label";
            this.column4_label.Size = new System.Drawing.Size(53, 13);
            this.column4_label.TabIndex = 0;
            this.column4_label.Text = "Unit Price";
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.column3_listbox);
            this.panel8.Controls.Add(this.panel9);
            this.panel8.Location = new System.Drawing.Point(208, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(125, 262);
            this.panel8.TabIndex = 21;
            // 
            // column3_listbox
            // 
            this.column3_listbox.BackColor = System.Drawing.SystemColors.Control;
            this.column3_listbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.column3_listbox.FormattingEnabled = true;
            this.column3_listbox.Items.AddRange(new object[] {
            "<quantity1>",
            "<quantity2>",
            "<quantity3>"});
            this.column3_listbox.Location = new System.Drawing.Point(0, 37);
            this.column3_listbox.Name = "column3_listbox";
            this.column3_listbox.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.column3_listbox.Size = new System.Drawing.Size(122, 223);
            this.column3_listbox.TabIndex = 55;
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.column3_label);
            this.panel9.Location = new System.Drawing.Point(0, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(122, 37);
            this.panel9.TabIndex = 0;
            // 
            // column3_label
            // 
            this.column3_label.AutoSize = true;
            this.column3_label.Location = new System.Drawing.Point(35, 10);
            this.column3_label.Name = "column3_label";
            this.column3_label.Size = new System.Drawing.Size(46, 13);
            this.column3_label.TabIndex = 0;
            this.column3_label.Text = "Quantity";
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.column2_listbox);
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Location = new System.Drawing.Point(100, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(109, 262);
            this.panel6.TabIndex = 20;
            // 
            // column2_listbox
            // 
            this.column2_listbox.BackColor = System.Drawing.SystemColors.Control;
            this.column2_listbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.column2_listbox.FormattingEnabled = true;
            this.column2_listbox.Items.AddRange(new object[] {
            "<prodName1>",
            "<prodName2>",
            "<prodName3>"});
            this.column2_listbox.Location = new System.Drawing.Point(-1, 37);
            this.column2_listbox.Name = "column2_listbox";
            this.column2_listbox.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.column2_listbox.Size = new System.Drawing.Size(109, 223);
            this.column2_listbox.TabIndex = 54;
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.column2_label);
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(109, 37);
            this.panel7.TabIndex = 0;
            // 
            // column2_label
            // 
            this.column2_label.AutoSize = true;
            this.column2_label.Location = new System.Drawing.Point(18, 10);
            this.column2_label.Name = "column2_label";
            this.column2_label.Size = new System.Drawing.Size(75, 13);
            this.column2_label.TabIndex = 0;
            this.column2_label.Text = "Product Name";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.column1_listbox);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(102, 262);
            this.panel4.TabIndex = 19;
            // 
            // column1_listbox
            // 
            this.column1_listbox.BackColor = System.Drawing.SystemColors.Control;
            this.column1_listbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.column1_listbox.FormattingEnabled = true;
            this.column1_listbox.Items.AddRange(new object[] {
            "<prodID1>",
            "<prodID2>",
            "<prodID3>"});
            this.column1_listbox.Location = new System.Drawing.Point(-2, 37);
            this.column1_listbox.Name = "column1_listbox";
            this.column1_listbox.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.column1_listbox.Size = new System.Drawing.Size(103, 223);
            this.column1_listbox.TabIndex = 53;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.column1_label);
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(102, 37);
            this.panel5.TabIndex = 0;
            // 
            // column1_label
            // 
            this.column1_label.AutoSize = true;
            this.column1_label.Location = new System.Drawing.Point(37, 10);
            this.column1_label.Name = "column1_label";
            this.column1_label.Size = new System.Drawing.Size(18, 13);
            this.column1_label.TabIndex = 0;
            this.column1_label.Text = "ID";
            // 
            // panel3
            // 
            this.panel3.Location = new System.Drawing.Point(339, 259);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 109);
            this.panel3.TabIndex = 18;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(305, 484);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(22, 13);
            this.label16.TabIndex = 16;
            this.label16.Text = "kg.";
            // 
            // totalOrderWeight_label
            // 
            this.totalOrderWeight_label.AutoSize = true;
            this.totalOrderWeight_label.Location = new System.Drawing.Point(195, 484);
            this.totalOrderWeight_label.Name = "totalOrderWeight_label";
            this.totalOrderWeight_label.Size = new System.Drawing.Size(103, 13);
            this.totalOrderWeight_label.TabIndex = 15;
            this.totalOrderWeight_label.Text = "________________";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(70, 484);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(115, 13);
            this.label14.TabIndex = 14;
            this.label14.Text = "Total Weight of Order :";
            // 
            // totalNumOrderPieces_label
            // 
            this.totalNumOrderPieces_label.AutoSize = true;
            this.totalNumOrderPieces_label.Location = new System.Drawing.Point(195, 454);
            this.totalNumOrderPieces_label.Name = "totalNumOrderPieces_label";
            this.totalNumOrderPieces_label.Size = new System.Drawing.Size(103, 13);
            this.totalNumOrderPieces_label.TabIndex = 13;
            this.totalNumOrderPieces_label.Text = "________________";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(24, 454);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(164, 13);
            this.label12.TabIndex = 12;
            this.label12.Text = "Total Number of Pieces in Order :";
            // 
            // poNumber_label
            // 
            this.poNumber_label.AutoSize = true;
            this.poNumber_label.Location = new System.Drawing.Point(489, 39);
            this.poNumber_label.Name = "poNumber_label";
            this.poNumber_label.Size = new System.Drawing.Size(68, 13);
            this.poNumber_label.TabIndex = 10;
            this.poNumber_label.Text = "<poNumber>";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(418, 39);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "P.O. Number:";
            // 
            // orderDate_label
            // 
            this.orderDate_label.AutoSize = true;
            this.orderDate_label.Location = new System.Drawing.Point(486, 9);
            this.orderDate_label.Name = "orderDate_label";
            this.orderDate_label.Size = new System.Drawing.Size(67, 13);
            this.orderDate_label.TabIndex = 8;
            this.orderDate_label.Text = "<order date>";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(408, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Purchase Date:";
            // 
            // phoneNumber_label
            // 
            this.phoneNumber_label.AutoSize = true;
            this.phoneNumber_label.Location = new System.Drawing.Point(48, 52);
            this.phoneNumber_label.Name = "phoneNumber_label";
            this.phoneNumber_label.Size = new System.Drawing.Size(87, 13);
            this.phoneNumber_label.TabIndex = 6;
            this.phoneNumber_label.Text = "<phone number>";
            // 
            // firstLastName_label
            // 
            this.firstLastName_label.AutoSize = true;
            this.firstLastName_label.Location = new System.Drawing.Point(48, 39);
            this.firstLastName_label.Name = "firstLastName_label";
            this.firstLastName_label.Size = new System.Drawing.Size(115, 13);
            this.firstLastName_label.TabIndex = 5;
            this.firstLastName_label.Text = "<last name, first name>";
            // 
            // custID_label
            // 
            this.custID_label.AutoSize = true;
            this.custID_label.Location = new System.Drawing.Point(48, 26);
            this.custID_label.Name = "custID_label";
            this.custID_label.Size = new System.Drawing.Size(50, 13);
            this.custID_label.TabIndex = 4;
            this.custID_label.Text = "<custID>";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 52);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Phone: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Name: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(21, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "ID:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer Information";
            // 
            // print_button
            // 
            this.print_button.Image = ((System.Drawing.Image)(resources.GetObject("print_button.Image")));
            this.print_button.Location = new System.Drawing.Point(530, 608);
            this.print_button.Name = "print_button";
            this.print_button.Size = new System.Drawing.Size(185, 62);
            this.print_button.TabIndex = 51;
            this.print_button.UseVisualStyleBackColor = true;
            this.print_button.Click += new System.EventHandler(this.print_button_Click);
            // 
            // exit_button
            // 
            this.exit_button.Image = ((System.Drawing.Image)(resources.GetObject("exit_button.Image")));
            this.exit_button.Location = new System.Drawing.Point(730, 608);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(181, 62);
            this.exit_button.TabIndex = 50;
            this.exit_button.UseVisualStyleBackColor = true;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            // 
            // back_button
            // 
            this.back_button.Image = ((System.Drawing.Image)(resources.GetObject("back_button.Image")));
            this.back_button.Location = new System.Drawing.Point(322, 608);
            this.back_button.Name = "back_button";
            this.back_button.Size = new System.Drawing.Size(185, 62);
            this.back_button.TabIndex = 49;
            this.back_button.UseVisualStyleBackColor = true;
            this.back_button.Click += new System.EventHandler(this.back_button_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1109, 530);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(143, 140);
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1083, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(169, 136);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // Screen3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 682);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.print_button);
            this.Controls.Add(this.exit_button);
            this.Controls.Add(this.back_button);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Screen3";
            this.RightToLeftLayout = true;
            this.Text = "Screen3";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button exit_button;
        private System.Windows.Forms.Button back_button;
        private System.Windows.Forms.Button print_button;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label totalOrderWeight_label;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label totalNumOrderPieces_label;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label poNumber_label;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label orderDate_label;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label phoneNumber_label;
        private System.Windows.Forms.Label firstLastName_label;
        private System.Windows.Forms.Label custID_label;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label column5_label;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label column4_label;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label column3_label;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label column2_label;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label column1_label;
        private System.Windows.Forms.Label total_label;
        private System.Windows.Forms.Label subtotal_label;
        private System.Windows.Forms.Label tax_label;
        private System.Windows.Forms.ListBox column4_listbox;
        private System.Windows.Forms.ListBox column3_listbox;
        private System.Windows.Forms.ListBox column2_listbox;
        private System.Windows.Forms.ListBox column1_listbox;
        private System.Windows.Forms.ListBox column5_listbox;
    }
}