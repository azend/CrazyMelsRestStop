﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrazyMelsClient
{
    static class urlClass
    {
        public const string url = "http://localhost:1973/";
    }
}
